#ifndef QGF2D_SYSTEM_HEADER
#define QGF2D_SYSTEM_HEADER

namespace qgf
{
    bool initDirectory();
}

#endif
